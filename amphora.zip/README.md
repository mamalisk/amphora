# Toggle switches

run `npm start` for the app and `npm test` to execute the tests.